// @flow
import { compose } from 'recompose';

import AvailableInFullVersionView from './AvailableInFullVersionView';

export default compose()(AvailableInFullVersionView);
