// @flow
import { compose } from 'recompose';

import PagesView from './PagesView';

export default compose()(PagesView);
