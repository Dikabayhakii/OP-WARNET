export default {
  primaryLight: 'Lato-Light',
  primaryRegular: 'Lato-Regular',
  primaryBold: 'Lato-Bold',
  primarySemiBold: 'Lato-SemiBold',
};
